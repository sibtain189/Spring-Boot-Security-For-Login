package com.jwt.tinyURL;

public class Analytics {

	public boolean enabled;

	public boolean getEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public boolean getPublic_one() {
		return public_one;
	}

	public void setPublic_one(boolean public_one) {
		this.public_one = public_one;
	}

	public boolean public_one;
}