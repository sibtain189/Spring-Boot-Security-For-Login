package com.jwt.tinyURL;

public class Errors {

}
